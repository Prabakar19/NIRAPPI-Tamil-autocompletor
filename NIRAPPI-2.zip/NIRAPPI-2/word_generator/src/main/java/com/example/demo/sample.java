package com.example.demo;

import java.io.IOException;

public class sample {

	//public static void main(String arg[]) throws Exception
    public String result(String sentence,String pos,String case1) throws Exception
	{
    	String result="";
		N_CM2 word_obj=new N_CM2();
		word_verb vrb_obj=new word_verb();
		System.out.println("pos:"+pos);
		pos=pos.trim();
//		if(pos.equalsIgnoreCase("noun"))
//		{
//			System.out.println("insde ");
			result+=vrb_obj.verbgeneration(sentence,case1).toString();
			result=word_obj.NounCMGen1(sentence,case1).toString();
//		}
//		else if(pos.equalsIgnoreCase("verb"))
//		{
			
//		}
//		else
//		{
//			result="wrong pos";
//		}
		
		//    	System.out.println(word_obj.NounCMGen1("இந்தியா","N1+AdjectivalSuffix"));
		//NI+PP
		//N1+CM
		//n1+plural
		//Pl+CM
		//N1+AdjectivalSuffix
    	
//    	
//    	System.out.println(vrb_obj.verbgeneration("நுழை","வினை+எச்சம்+எதிர்மறை"));
    		//வினை+காலம்+பால்/இட/எண்
    		//வினை+உம்+பெயரெச்ச பின்னொட்டு
    		//வினை+இறந்தகாலம்+நிபந்தனை விகுதி
    		//வினை+எச்சம்+ஈற்றசை
    		//வினை+எச்சம்+நிலை+(பால்/இட/எண¢)/(தொ.பெ.விகுதி)/(+வே.உ)
    		//ஏ.மு.ஒ.விகுதி(ISM) / ஏ.மு.ப.விகுத¤(IPM)
    		//வினை+காலம்+பெ.எச்சம்+தொ.பெ
    	//வினை+காலம்+பெ.எச்சம்+பெயரெச்ச பின்னொட்டு
    	//வினை+எச்சம்+எதிர்மறை
       	return result;
    }

}
