package com.example.demo;

import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

@Service
public class Generator_service {

	@SuppressWarnings("unchecked")
	public JSONObject getObject(String sentence,String pos) throws Exception
	{
		String case1="N1";
		JSONObject obj=new JSONObject();
		sample sam = new sample();
		String ans=sam.result(sentence, pos, case1);
		System.out.println("ans: "+ans);
		
		if(ans.equals(""))
			ans="தவறான உள்ளீடு";
		
		obj.put("Generated",ans);
		
		return obj;
	}
}
